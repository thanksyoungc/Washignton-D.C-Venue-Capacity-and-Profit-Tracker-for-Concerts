import datetime
from dataclasses import dataclass

@dataclass
class Event:
    date: datetime.date
    venue_name: str
    artist_name: str
    expected_attendance: int
    ticket_price: float
    artist_cost: float
    operations_cost: float
    rental_cost: float
    fees_percent: float = 0.10
    merch_spend_per_head: float = 0.0

    # Creates floating point values for accurate and concise data and information

    def ticket_gross(self) -> float:
        return self.expected_attendance * self.ticket_price

    def fees_total(self) -> float:
        return self.ticket_gross() * self.fees_percent

    def merch_gross(self) -> float:
        return self.expected_attendance * self.merch_spend_per_head

    def total_revenue(self) -> float:
        return self.ticket_gross() + self.merch_gross()

    def total_costs(self) -> float:
        return self.artist_cost + self.operations_cost + self.rental_cost + self.fees_total()

    def profit(self) -> float:
        return self.total_revenue() - self.total_costs()