from dataclasses import dataclass

@dataclass
class Venue:
    name: str
    capacity: int
    rental_cost: float
    city: str

VENUES = {
    "Jammin Java": Venue("Jammin Java", 200, 2500, "Vienna, VA"),
    "Pearl Street Warehouse": Venue("Pearl Street Warehouse", 300, 3000, "Washington, DC"),
    "Rams Head On Stage": Venue("Rams Head On Stage", 300, 3500, "Annapolis, MD"),
    "The Atlantis": Venue("The Atlantis", 450, 5000, "Washington, DC"),
    "Union Stage": Venue("Union Stage", 450, 4500, "Washington, DC"),
    "The Birchmere": Venue("The Birchmere", 500, 5500, "Alexandria, VA"),
    "Baltimore Soundstage": Venue("Baltimore Soundstage", 1000, 8000, "Baltimore, MD"),
    "9:30 Club": Venue("9:30 Club", 1200, 12000, "Washington, DC"),
    "Lincoln Theatre": Venue("Lincoln Theatre", 1225, 12000, "Washington, DC"),
    "Rams Head Live / Nevermore Hall": Venue("Rams Head Live / Nevermore Hall", 1500, 14000, "Baltimore, MD"),
    "Warner Theatre": Venue("Warner Theatre", 1900, 18000, "Washington, DC"),
    "The Fillmore Silver Spring": Venue("The Fillmore Silver Spring", 2000, 20000, "Silver Spring, MD"),
    "Hippodrome Theatre": Venue("Hippodrome Theatre", 2300, 22000, "Baltimore, MD"),
    "Echostage": Venue("Echostage", 3000, 24000, "Washington, DC"),
    "MGM National Harbor Theater": Venue("MGM National Harbor Theater", 3500, 30000, "Oxon Hill, MD"),
    "Pier Six Pavilion": Venue("Pier Six Pavilion", 4400, 28000, "Baltimore, MD"),
    "The Anthem": Venue("The Anthem", 6000, 35000, "Washington, DC"),
    "EagleBank Arena": Venue("EagleBank Arena", 10000, 100000, "Fairfax, VA"),
    "Merriweather Post Pavilion": Venue("Merriweather Post Pavilion", 19319, 75000, "Columbia, MD"),
    "CFG Bank Arena": Venue("CFG Bank Arena", 20000, 120000, "Baltimore, MD"),
    "Capital One Arena": Venue("Capital One Arena", 20000, 150000, "Washington, DC"),
    "M&T Bank Stadium": Venue("M&T Bank Stadium", 70000, 350000, "Baltimore, MD"),
}